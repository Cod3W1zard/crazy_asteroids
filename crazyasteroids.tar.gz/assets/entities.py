import pygame
import math

WIDTH = 600
HEIGHT = 400

class Circle:
    def __init__(self, x, y, radius, color, velocity):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.velocity = velocity

class Missile:
    def __init__(self, position, velocity, color=(255, 0, 0)):
        self.position = position
        self.velocity = velocity
        self.color = color

class Ship:
    def __init__(self, screen, position, velocity, angle,color=(0, 255, 0)):
        self.screen = screen
        self.position = position
        self.velocity = velocity
        self.angle = angle
        self.color = color
        self.radians = math.radians(self.angle)
        self.forward = pygame.Vector2(math.cos(self.radians), -math.sin(self.radians))
        self.left = self.forward.rotate(90)
        self.right = self.forward.rotate(-90)

    def draw(self):

        if self.position.x > WIDTH:
            self.position.x = 0

        if self.position.x < 0:
            self.position.x = WIDTH

        if self.position.y > HEIGHT:
            self.position.y = 0

        if self.position.y < 0:
            self.position.y = HEIGHT

        
        self.radians = math.radians(self.angle)
        self.forward = pygame.Vector2(math.cos(self.radians), -math.sin(self.radians))
        self.left = self.forward.rotate(90)
        self.right = self.forward.rotate(-90)

        self.position += self.velocity
        self.velocity *= 0.99
        
        pygame.draw.polygon(self.screen, self.color, [
            self.position + self.forward * 20,
            self.position + self.left * 8,
            self.position + self.forward * 8,
            self.position + self.right * 8
        ])

class Enemy(Ship):
    def __init__(self, screen, position, velocity, angle, color=(255, 0, 0)):
        super().__init__(screen, position, velocity, angle, color)
        self.radians = math.radians(self.angle)
        self.forward = pygame.Vector2(math.cos(self.radians), -math.sin(self.radians))
        self.left = self.forward.rotate(90)
        self.right = self.forward.rotate(-90)
        self.range = 45
        self.detection_distance = 200
        self.state = "PATROL"
        self.cooldown = 30
        self.cooldown_counter = 0

    def search(self, player, missiles):
        self.cooldown_counter -= 1

        direction_to_player = (player.position - self.position + self.forward * 20).normalize()

        pygame.draw.line(
            self.screen,
            (255, 0, 0),
            self.position + self.forward * 20,
            self.position + self.forward * self.detection_distance,
            3
        )

        # pygame.draw.line(
        #             self.screen,
        #             (255, 0, 0),
        #             self.position + self.forward * 20,
        #             pygame.Vector2((self.position + self.forward * self.detection_distance).x * math.cos(math.radians(self.range)), (self.position + self.forward * self.detection_distance).y * -math.sin(math.radians(self.range))),
        #             3
        #         )

        pygame.draw.circle(
            self.screen,
            (128, 128, 128),
            self.position,
            self.detection_distance,
            1
        )

        if self.forward.dot(direction_to_player) > math.cos(math.radians(self.range)) and player.position.distance_to(self.position) < self.detection_distance:
            self.color = (255, 0, 0)
            self.state = "ATTACK"
        else: 
            self.color = (255, 255, 0)
            self.state = "PATROL"

        if self.state == "ATTACK":
            if self.forward.cross(direction_to_player) > 0.05:
                self.angle -= 2
            elif self.forward.cross(direction_to_player) < -0.05:
                self.angle += 2
            else:
                if self.cooldown_counter <= 0:
                    self.cooldown_counter = self.cooldown
                    direction = self.forward
                    MISSILE_SPEED = 7
                    missile_velocity = direction * MISSILE_SPEED
                    missile_position = self.position + self.forward * 20
                    missile = Missile(missile_position, missile_velocity)
                    missiles.append(missile)
        
