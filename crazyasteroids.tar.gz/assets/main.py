import asyncio

import pygame
import random
import math
import entities

async def main():

    pygame.init()

    font = pygame.font.Font(None, 50)
    text_surface = font.render("PATROL", True, (255, 255, 255))
    text_rect = text_surface.get_rect()
    text_rect.center = (100, 50)

    WIDTH = 600
    HEIGHT = 400

    screen = screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE | pygame.SCALED)
    pygame.display.set_caption("Cupcake Collector")
    clock = pygame.time.Clock()
    running = True

    circles = []

    for circle in range(6):
        circles.append(
            entities.Circle(
                random.randint(50, WIDTH - 50), 
                random.randint(50, HEIGHT - 50), 
                random.randint(10, 30), 
                (255,255,255), 
                pygame.math.Vector2(
                    random.uniform(-2, 2),
                    random.uniform(-2, 2)
                )
            )
        )



    missiles = []



    player = entities.Ship(screen, pygame.Vector2(300, 200), pygame.Vector2(0, 0), 90)

    enemy = entities.Enemy(screen, pygame.Vector2(300, 300), pygame.Vector2(0, 0), 90, color=(255, 0, 0))

    while running:
        # EVENT
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                    direction = player.forward
                    MISSILE_SPEED = 7
                    missile_velocity = direction * MISSILE_SPEED
                    missile_position = player.position + player.forward * 20
                    missile = entities.Missile(missile_position, missile_velocity)
                    missiles.append(missile)

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            player.angle += 5

        if keys[pygame.K_RIGHT]:
            player.angle -= 5

        if keys[pygame.K_UP]:
            player.velocity += player.forward * 0.1

        for missile in missiles:
            missile.position += missile.velocity
            for circle in circles:
                distance = missile.position.distance_to(pygame.Vector2(circle.x, circle.y))
                if distance < 5 + circle.radius:
                    circles.remove(circle)
                    missiles.remove(missile)
                    break

        




        for i in range(len(circles)):
            for j in range(i + 1, len(circles)):

                circle1, circle2 = circles[i], circles[j]
                normalx = circle2.x - circle1.x
                normaly = circle2.y - circle1.y
                distance = math.sqrt(normalx ** 2 + normaly ** 2)
                normalx /= distance
                normaly /= distance
                

                if distance < circle1.radius + circle2.radius:

                    overlap = circle1.radius + circle2.radius - distance
                    total_mass = circle1.radius + circle2.radius
                    circle1.x -= normalx * overlap * (circle2.radius / total_mass)
                    circle1.y -= normaly * overlap * (circle2.radius / total_mass)
                    circle2.x += normalx * overlap * (circle1.radius / total_mass)
                    circle2.y += normaly * overlap * (circle1.radius / total_mass)

                    circle1.velocity = circle1.velocity.reflect(pygame.math.Vector2(normalx, normaly)) * (circle2.radius / total_mass)
                    circle2.velocity = circle2.velocity.reflect(pygame.math.Vector2(normalx, normaly)) * (circle1.radius / total_mass)
                    
        
        screen.fill((20, 24, 40))
        
        for circle in circles:
            circle.x += circle.velocity.x
            circle.y += circle.velocity.y

            if circle.x - circle.radius < 0 or circle.x + circle.radius > WIDTH:
                circle.velocity.x *= -1
            if circle.y - circle.radius < 0 or circle.y + circle.radius > HEIGHT:
                circle.velocity.y *= -1
            pygame.draw.circle(screen, circle.color, (int(circle.x), int(circle.y)), circle.radius)
        for missile in missiles:
            pygame.draw.circle(screen, missile.color, (int(missile.position.x), int(missile.position.y)), 5)

        
        
        
        player.draw()
        enemy.search(player, missiles)
        enemy.draw()
        text_surface = font.render(enemy.state, True, (255, 255, 255))
        screen.blit(text_surface, text_rect)
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())